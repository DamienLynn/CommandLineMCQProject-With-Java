package Lithan.L4M1;

import org.junit.Test;

import static org.junit.Assert.*;

public class ChooseQuestionTest {
    @Test
    public void remakeq(){
        int choice = 3 ;
        assertEquals(3,choice);
    }

}