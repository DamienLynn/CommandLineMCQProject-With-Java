package Lithan.L4M1;

import org.junit.Test;

import static org.junit.Assert.*;

public class TryagainTest {
    @Test
    public void Retry(){
        int retry = 2 ;
        assertEquals(1,retry);
    }

}