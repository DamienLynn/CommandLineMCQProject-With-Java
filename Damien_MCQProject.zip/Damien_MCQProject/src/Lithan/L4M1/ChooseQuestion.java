package Lithan.L4M1;


import java.util.Scanner;

public class ChooseQuestion {
    public static void remakeq(){
        System.out.println("Choose one MCQset");
        System.out.println("1.Java");
        System.out.println("2.HTML");
        System.out.println("3.CSS");
        Scanner sc = new Scanner(System.in);
        int choice = sc.nextInt();
        Questions q = new Questions ();
        q.choose(choice);
    }
}
