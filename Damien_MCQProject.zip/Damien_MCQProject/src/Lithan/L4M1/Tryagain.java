package Lithan.L4M1;
import Lithan.L4M1.ChooseQuestion;

import java.util.Scanner;

public class Tryagain {
    public static void Retry() {
        System.out.println("You can choose the following options.");
        System.out.println("Press 1 for retry the Question.");
        System.out.println("Press 2 for End the Section.");
        Scanner sc = new Scanner(System.in);
        int retry = sc.nextInt();
        if(retry ==1){
            ChooseQuestion Q = new ChooseQuestion();
            Q.remakeq();
        }
        else{
            System.exit(0);
        }
    }
}