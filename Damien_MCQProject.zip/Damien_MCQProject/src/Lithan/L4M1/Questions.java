package Lithan.L4M1;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Questions {
    static int count = 0;
    static int wrong = 0;
    public static void choose(int choice) {

        switch (choice) {
            case 1: {
                String csv = "src\\MCQFile\\Java.csv";
                BufferedReader br = null;
                String space = "";
                String comma = ",";

                try {
                    br = new BufferedReader(new FileReader(csv));
                    while ((space = br.readLine()) != null) {
                        String[] Question = space.split(comma);
                        System.out.println(Question[0] + "\n" + Question[1] + "\n" + Question[2] + "\n" + Question[3] + "\n" + Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("The answer is correct");
                            count++;
                        } else {
                            System.out.println("The answer is wrong");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            break;
            case 2: {
                String csv = "src\\MCQFile\\q1.csv";
                BufferedReader br = null;
                String space = "";
                String comma = ",";

                try {
                    br = new BufferedReader(new FileReader(csv));
                    while ((space = br.readLine()) != null) {
                        String[] Question = space.split(comma);
                        System.out.println(Question[0] + "\n" + Question[1] + "\n" + Question[2] + "\n" + Question[3] + "\n" + Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("The answer is correct");
                            count++;
                        } else {
                            System.out.println("The answer is wrong");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            break;
            case 3: {
                String csv = "src\\MCQFile\\q2.csv";
                BufferedReader br = null;
                String space = "";
                String comma = ",";

                try {
                    br = new BufferedReader(new FileReader(csv));
                    while ((space = br.readLine()) != null) {
                        String[] Question = space.split(comma);
                        System.out.println(Question[0] + "\n" + Question[1] + "\n" + Question[2] + "\n" + Question[3] + "\n" + Question[4]);
                        Scanner sc = new Scanner(System.in);
                        String answer = sc.next();
                        if (Question[5].equals(answer)) {
                            System.out.println("The answer is correct");
                            count++;
                        } else {
                            System.out.println("The answer is wrong");
                            wrong++;
                        }
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
            break;
            default:
                System.out.println("Your input number is invalid");
                System.out.println("Do you want to try again?");
                Tryagain a = new Tryagain();
                a.Retry();
        }
        Sum C = new Sum();
        C.calculate(count,wrong);
    }
}