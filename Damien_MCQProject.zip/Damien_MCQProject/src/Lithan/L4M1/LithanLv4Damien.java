package Lithan.L4M1;
import java.util.Scanner;

public class LithanLv4Damien {
    public static void main(String[] args) {
        System.out.println("***Welcome to ABC Learning Centre***");
        System.out.println("****Welcome to MCQ Project****");
        System.out.println("Enter your name");
        Scanner sc = new Scanner(System.in);
        String name = sc.nextLine();
        ChooseQuestion q = new ChooseQuestion();
        q.remakeq();

    }
}