package Lithan.L4M1;

import com.sun.tools.javac.Main;

public class Sum {
    public static void calculate(int count,int wrong){
        double avgresult = count*10;


        System.out.println("Dear Damien You answered 10 questions, You correct"+count+"questions and You wrong"+wrong+"questions");
        System.out.println("So you got"+avgresult+"%");

        Tryagain a = new Tryagain();
        a.Retry();
    }
}
